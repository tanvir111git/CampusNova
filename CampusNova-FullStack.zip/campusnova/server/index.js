/**
 * CampusNova Backend Server
 */
const express = require('express');
const cors = require('cors');
const path = require('path');
const jwt = require('jsonwebtoken');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "campusnova-secret-change-in-production-2026";
const GEMINI_KEY = process.env.GEMINI_KEY || "AQ.Ab8RN6JmzgwsntdGAAzzyqHBkIKZnbFC9twpMwVEbIc3VetY7w";

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// ---------- Auth Middleware ----------
function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = db.findUserById(payload.id);
    if (!req.user) return res.status(401).json({ error: 'User not found' });
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// ---------- Auth Routes ----------
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
    const user = db.authenticate(email, password);
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ user, token });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/auth/register', (req, res) => {
  try {
    const { name, email, password, department, batch, university } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password required' });
    const user = db.createUser({ name, email, password, department, batch, university });
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ user, token });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/auth/me', auth, (req, res) => {
  res.json({ user: db.publicUser(req.user) });
});

// ---------- Users ----------
app.get('/api/users', auth, (req, res) => {
  res.json(db.getAllUsers());
});

app.get('/api/users/:id', auth, (req, res) => {
  const user = db.findUserById(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(db.publicUser(user));
});

app.patch('/api/users/:id', auth, (req, res) => {
  if (req.user.id !== req.params.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const updated = db.updateUser(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'User not found' });
  res.json(updated);
});

// ---------- Gemini Proxy (keeps API key secret) ----------
app.post('/api/nova/chat', auth, async (req, res) => {
  try {
    const { message, history = [], model = 'gemini-2.0-flash' } = req.body;
    if (!message) return res.status(400).json({ error: 'Message required' });

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(GEMINI_KEY)}`;

    const contents = [
      ...history.map(h => ({
        role: h.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: h.content || h.text || '' }]
      })),
      { role: 'user', parts: [{ text: message }] }
    ];

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents })
    });

    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({ error: data.error?.message || 'Gemini error' });
    }

    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response';
    res.json({ reply: text });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ---------- Health ----------
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', app: 'CampusNova', version: '2.0.0' });
});

// ---------- Serve Frontend ----------
app.use(express.static(path.join(__dirname, '../public')));

// SPA-style fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.listen(PORT, () => {
  console.log(`\n  CampusNova is running!`);
  console.log(`  → http://localhost:${PORT}`);
  console.log(`  → API: http://localhost:${PORT}/api/health\n`);
});

/**
 * Server-side persistent database (JSON file)
 */
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const DB_PATH = path.join(__dirname, 'data.json');

const ADMIN_ACCOUNTS = [
  { email: "tanvir242-35-512@diu.edu.bd", password: "123thr111", name: "Md. Tanvir Hossain", id: "admin1" },
  { email: "sukanta242-35-493@diu.edu.bd", password: "123ss111", name: "Sukanta Sarkar", id: "admin2" },
  { email: "mehedi242-35-046@diu.edu.bd", password: "123mh111", name: "Mehedi Hasan", id: "admin3" },
  { email: "pulock242-35-599@diu.edu.bd", password: "123pr111", name: "Pulok Roy", id: "admin4" },
];

function createSeed() {
  const now = new Date().toISOString();
  const users = [
    ...ADMIN_ACCOUNTS.map((a) => ({
      id: a.id,
      name: a.name,
      email: a.email,
      password: bcrypt.hashSync(a.password, 10),
      role: "admin",
      department: "CSE",
      batch: "2024",
      bio: "CampusNova administrator & Team WebForge member.",
      skills: ["Leadership", "QA", "Web Development"],
      expertise: ["System Design", "Project Management"],
      avatarSeed: a.name.split(" ")[0].toLowerCase(),
      xp: 1000,
      level: 10,
      streak: 30,
      theme: "dark",
      createdAt: "2026-05-01T10:00:00Z",
    })),
    {
      id: "t1",
      name: "Dr. Sarah Ahmed",
      email: "sarah.ahmed@diu.edu.bd",
      password: bcrypt.hashSync("teacher123", 10),
      role: "teacher",
      department: "Computer Science & Engineering",
      batch: "Faculty",
      bio: "Associate Professor specializing in Machine Learning and Data Science.",
      skills: ["Machine Learning", "Python", "Research Methods"],
      expertise: ["Artificial Intelligence", "Data Science"],
      avatarSeed: "sarah",
      xp: 2500,
      level: 15,
      streak: 90,
      theme: "light",
      createdAt: "2026-04-01T10:00:00Z",
    },
    {
      id: "t2",
      name: "Prof. Karim Hassan",
      email: "karim.hassan@diu.edu.bd",
      password: bcrypt.hashSync("teacher123", 10),
      role: "teacher",
      department: "Software Engineering",
      batch: "Faculty",
      bio: "Professor of Software Engineering. Research interests in distributed systems.",
      skills: ["Software Architecture", "Cloud Computing", "Java"],
      expertise: ["Distributed Systems", "Cloud", "DevOps"],
      avatarSeed: "karim",
      xp: 2200,
      level: 14,
      streak: 60,
      theme: "dark",
      createdAt: "2026-04-05T10:00:00Z",
    },
    {
      id: "t3",
      name: "Ms. Fatima Noor",
      email: "fatima.noor@diu.edu.bd",
      password: bcrypt.hashSync("teacher123", 10),
      role: "teacher",
      department: "Computer Science & Engineering",
      batch: "Faculty",
      bio: "Lecturer in Web Technologies and Human-Computer Interaction.",
      skills: ["HTML/CSS", "JavaScript", "UI/UX", "React"],
      expertise: ["Web Engineering", "HCI"],
      avatarSeed: "fatima",
      xp: 1800,
      level: 12,
      streak: 45,
      theme: "light",
      createdAt: "2026-04-10T10:00:00Z",
    },
    {
      id: "u1",
      name: "Anika Rahman",
      email: "anika@student.edu",
      password: bcrypt.hashSync("demo123", 10),
      role: "student",
      department: "Computer Science",
      batch: "2025",
      university: "Daffodil International University",
      bio: "First-year CS student looking for study partners.",
      skills: ["Python", "Calculus", "Note-taking"],
      expertise: [],
      avatarSeed: "anika",
      xp: 120,
      level: 2,
      streak: 3,
      theme: "dark",
      createdAt: "2026-07-10T10:00:00Z",
    },
    {
      id: "u2",
      name: "Rafi Ahmed",
      email: "rafi@student.edu",
      password: bcrypt.hashSync("demo123", 10),
      role: "student",
      department: "Software Engineering",
      batch: "2024",
      university: "Daffodil International University",
      bio: "Group project lead. Love building things.",
      skills: ["JavaScript", "React", "Project Management"],
      expertise: [],
      avatarSeed: "rafi",
      xp: 480,
      level: 5,
      streak: 12,
      theme: "dark",
      createdAt: "2026-06-01T10:00:00Z",
    },
    {
      id: "u3",
      name: "Nusrat Jahan",
      email: "nusrat@student.edu",
      password: bcrypt.hashSync("demo123", 10),
      role: "student",
      department: "Computer Science",
      batch: "2023",
      university: "Daffodil International University",
      bio: "Club coordinator. Passionate about community.",
      skills: ["Event Planning", "Public Speaking", "Java"],
      expertise: [],
      avatarSeed: "nusrat",
      xp: 720,
      level: 7,
      streak: 21,
      theme: "light",
      createdAt: "2026-05-15T10:00:00Z",
    }
  ];

  return {
    users,
    groups: [],
    posts: [],
    events: [],
    notifications: [],
    createdAt: now
  };
}

function load() {
  if (!fs.existsSync(DB_PATH)) {
    const seed = createSeed();
    save(seed);
    return seed;
  }
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch (e) {
    const seed = createSeed();
    save(seed);
    return seed;
  }
}

function save(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function publicUser(u) {
  if (!u) return null;
  const { password, ...rest } = u;
  return rest;
}

module.exports = {
  load,
  save,
  publicUser,

  findUserByEmail(email) {
    return load().users.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
  },

  findUserById(id) {
    return load().users.find(u => u.id === id) || null;
  },

  getAllUsers() {
    return load().users.map(publicUser);
  },

  createUser({ name, email, password, department = "", batch = "", role = "student", university = "" }) {
    const db = load();
    if (db.users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
      throw new Error("Email already registered");
    }
    const user = {
      id: uuidv4(),
      name,
      email,
      password: bcrypt.hashSync(password, 10),
      role,
      department,
      batch,
      university,
      bio: "",
      skills: [],
      expertise: [],
      avatarSeed: name.split(" ")[0].toLowerCase(),
      xp: 0,
      level: 1,
      streak: 0,
      theme: "light",
      createdAt: new Date().toISOString()
    };
    db.users.push(user);
    save(db);
    return publicUser(user);
  },

  authenticate(email, password) {
    const user = this.findUserByEmail(email);
    if (!user) return null;
    if (!bcrypt.compareSync(password, user.password)) return null;
    return publicUser(user);
  },

  updateUser(id, updates) {
    const db = load();
    const idx = db.users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    const allowed = ['name', 'bio', 'department', 'batch', 'skills', 'expertise', 'theme', 'university', 'avatarSeed'];
    for (const key of allowed) {
      if (updates[key] !== undefined) db.users[idx][key] = updates[key];
    }
    save(db);
    return publicUser(db.users[idx]);
  }
};

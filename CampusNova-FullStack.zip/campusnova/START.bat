@echo off
title CampusNova Full-Stack
cd /d "%~dp0"
echo.
echo  Installing dependencies (first time only)...
call npm install
echo.
echo  Starting CampusNova server...
echo  Open: http://localhost:3000
echo.
start http://localhost:3000
node server/index.js
pause

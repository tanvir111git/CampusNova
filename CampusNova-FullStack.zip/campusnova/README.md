# CampusNova v2 — Full-Stack

Student collaboration hub with a **real Node.js backend**.

## Features

- Express backend with JWT authentication
- Persistent JSON database (users stored on server)
- Password hashing (bcrypt)
- Gemini AI proxy (API key stays on server)
- All original frontend pages still work
- Demo accounts pre-seeded

## Quick Start (Windows)

1. Extract the zip
2. Double-click **`START.bat`**

   → Server starts + browser opens at http://localhost:3000

## Manual Start

```bash
npm install
npm start
```

Then open: **http://localhost:3000**

## Demo Accounts

| Role     | Email                        | Password    |
|----------|------------------------------|-------------|
| Student  | anika@student.edu            | demo123     |
| Teacher  | karim.hassan@diu.edu.bd      | teacher123  |
| Admin    | tanvir242-35-512@diu.edu.bd  | 123thr111   |

## Project Structure

```
campusnova/
├── server/
│   ├── index.js      ← Express server + API
│   ├── db.js         ← Persistent user database
│   └── data.json     ← Created automatically
├── public/           ← Frontend (HTML/CSS/JS)
├── package.json
├── START.bat
└── README.md
```

## API Endpoints

| Method | Path                 | Description              |
|--------|----------------------|--------------------------|
| POST   | /api/auth/login      | Login                    |
| POST   | /api/auth/register   | Register                 |
| GET    | /api/auth/me         | Current user             |
| GET    | /api/users           | List users               |
| POST   | /api/nova/chat       | AI chat (proxied)        |
| GET    | /api/health          | Health check             |

## Notes

- Other features (groups, notes, events, etc.) still use browser localStorage for full offline capability.
- Auth is now real and server-side.
- Gemini key is no longer exposed in the frontend.

Team WebForge · Desktop & Web Programming

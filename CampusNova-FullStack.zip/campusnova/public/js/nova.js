/**
 * CampusNova — Nova AI (Google Gemini)
 * Multi-chat sessions + fast organized answers.
 */

const SESSIONS_KEY = "cn_nova_sessions_v1";
const ACTIVE_KEY = "cn_nova_active_v1";
const LEGACY_HISTORY_KEY = "cn_nova_history_v3";
const DEFAULT_GEMINI_KEY = "AQ.Ab8RN6JmzgwsntdGAAzzyqHBkIKZnbFC9twpMwVEbIc3VetY7w";

export function getApiKey() {
  return DEFAULT_GEMINI_KEY;
}

export function setApiKey() {}

function uid() {
  return "c_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function loadAllSessions(userId) {
  try {
    const all = JSON.parse(localStorage.getItem(SESSIONS_KEY) || "{}");
    if (!all[userId]) {
      // migrate legacy single history if present
      try {
        const legacy = JSON.parse(localStorage.getItem(LEGACY_HISTORY_KEY) || "{}");
        const msgs = legacy[userId] || [];
        if (msgs.length) {
          const id = uid();
          all[userId] = [{
            id,
            title: msgs.find((m) => m.role === "user")?.content?.slice(0, 42) || "Previous chat",
            updatedAt: Date.now(),
            messages: msgs.slice(-40),
          }];
          localStorage.setItem(SESSIONS_KEY, JSON.stringify(all));
        } else {
          all[userId] = [];
        }
      } catch {
        all[userId] = [];
      }
    }
    return all[userId];
  } catch {
    return [];
  }
}

function saveAllSessions(userId, sessions) {
  try {
    const all = JSON.parse(localStorage.getItem(SESSIONS_KEY) || "{}");
    all[userId] = sessions;
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(all));
  } catch (_) {}
}

export function listChats(userId) {
  return loadAllSessions(userId)
    .slice()
    .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
}

export function getActiveChatId(userId) {
  try {
    const map = JSON.parse(localStorage.getItem(ACTIVE_KEY) || "{}");
    return map[userId] || null;
  } catch {
    return null;
  }
}

export function setActiveChatId(userId, chatId) {
  try {
    const map = JSON.parse(localStorage.getItem(ACTIVE_KEY) || "{}");
    map[userId] = chatId;
    localStorage.setItem(ACTIVE_KEY, JSON.stringify(map));
  } catch (_) {}
}

export function getChat(userId, chatId) {
  return loadAllSessions(userId).find((c) => c.id === chatId) || null;
}

export function createChat(userId, title = "New chat") {
  const sessions = loadAllSessions(userId);
  const chat = {
    id: uid(),
    title,
    updatedAt: Date.now(),
    messages: [],
  };
  sessions.unshift(chat);
  saveAllSessions(userId, sessions.slice(0, 40));
  setActiveChatId(userId, chat.id);
  return chat;
}

export function saveChatMessages(userId, chatId, messages) {
  const sessions = loadAllSessions(userId);
  const i = sessions.findIndex((c) => c.id === chatId);
  if (i === -1) return;
  const firstUser = messages.find((m) => m.role === "user");
  sessions[i].messages = messages.slice(-50);
  sessions[i].updatedAt = Date.now();
  if (firstUser?.content) {
    const t = firstUser.content.trim().replace(/\s+/g, " ");
    sessions[i].title = t.length > 48 ? t.slice(0, 46) + "…" : t;
  }
  saveAllSessions(userId, sessions);
}

export function deleteChat(userId, chatId) {
  let sessions = loadAllSessions(userId).filter((c) => c.id !== chatId);
  saveAllSessions(userId, sessions);
  if (getActiveChatId(userId) === chatId) {
    setActiveChatId(userId, sessions[0]?.id || null);
  }
}

export function renameChat(userId, chatId, title) {
  const sessions = loadAllSessions(userId);
  const c = sessions.find((s) => s.id === chatId);
  if (!c) return;
  c.title = title.slice(0, 60);
  c.updatedAt = Date.now();
  saveAllSessions(userId, sessions);
}

// legacy compatibility
export function loadHistory(userId) {
  const id = getActiveChatId(userId);
  if (id) {
    const chat = getChat(userId, id);
    if (chat) return chat.messages || [];
  }
  const list = listChats(userId);
  if (list[0]) {
    setActiveChatId(userId, list[0].id);
    return list[0].messages || [];
  }
  return [];
}

export function saveHistory(userId, messages) {
  let id = getActiveChatId(userId);
  if (!id) {
    const chat = createChat(userId);
    id = chat.id;
  }
  saveChatMessages(userId, id, messages);
}

const SYSTEM = `You are Nova — CampusNova's AI assistant powered by Google Gemini.

Behave like the latest Gemini chat assistant:
- Natural, capable, and precise
- Answer first, then add useful structure
- Strong at studying, coding, math, science, writing, planning, and current events
- When LIVE NEWS CONTEXT is provided in the user message, treat it as up-to-date world information and use it
- If asked about news/current events and context is present, summarize clearly with key points
- Match length to the user (short by default)
- Do not invent private university rules
- Be helpful, not robotic`;

const MODELS = [
  "gemini-3.5-flash",
  "gemini-flash-lite-latest",
  "gemini-3.5-flash-lite",
  "gemini-3.7-flash",
  "gemini-3.1-flash-lite",
];

function needsLiveInfo(text) {
  const q = String(text || "").toLowerCase();
  return /\b(news|headline|headlines|today|tonight|this week|breaking|latest|current events|right now|who won|score|weather|election|worldwide|happening|update on|world news)\b/.test(q);
}

async function fetchWithTimeout(url, ms = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { Accept: "application/json, text/plain, */*" } });
    if (!res.ok) throw new Error(String(res.status));
    return res;
  } finally {
    clearTimeout(t);
  }
}

function parseRssTitles(xml, limit = 8) {
  const titles = [];
  try {
    const doc = new DOMParser().parseFromString(xml, "text/xml");
    const items = [...doc.querySelectorAll("item")].slice(0, limit);
    for (const item of items) {
      const title = (item.querySelector("title")?.textContent || "").trim();
      const link = (item.querySelector("link")?.textContent || "").trim();
      if (title) titles.push(link ? `${title} (${link})` : title);
    }
  } catch (_) {}
  return titles;
}

/** Pull live headlines so Gemini can answer current-world questions even without Search grounding quota */
export async function fetchLiveNewsContext() {
  const lines = [];
  // 1) Hacker News front page (CORS-friendly, live)
  try {
    const res = await fetchWithTimeout("https://hn.algolia.com/api/v1/search?tags=front_page&hitsPerPage=6", 7000);
    const data = await res.json();
    for (const h of data.hits || []) {
      if (h.title) lines.push(`• ${h.title}${h.url ? " — " + h.url : ""}`);
    }
  } catch (_) {}

  // 2) BBC World via AllOrigins proxy
  try {
    const res = await fetchWithTimeout(
      "https://api.allorigins.win/raw?url=" + encodeURIComponent("https://feeds.bbci.co.uk/news/world/rss.xml"),
      8000
    );
    const xml = await res.text();
    for (const t of parseRssTitles(xml, 6)) lines.push(`• ${t}`);
  } catch (_) {}

  // 3) Google News top stories via AllOrigins
  try {
    const res = await fetchWithTimeout(
      "https://api.allorigins.win/raw?url=" + encodeURIComponent("https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en"),
      8000
    );
    const xml = await res.text();
    for (const t of parseRssTitles(xml, 6)) lines.push(`• ${t}`);
  } catch (_) {}

  // dedupe
  const seen = new Set();
  const unique = [];
  for (const line of lines) {
    const key = line.toLowerCase().slice(0, 80);
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(line);
  }
  return unique.slice(0, 14);
}

function buildParts(message, attachments = []) {
  const parts = [];
  const textFiles = (attachments || []).filter((a) => a.kind === "text" && a.text);
  const binaries = (attachments || []).filter((a) => a.kind === "binary" && a.data && a.mimeType);

  let text = String(message || "");
  if (textFiles.length) {
    text += "\n\n---\nAttached file content:\n";
    for (const f of textFiles) text += `\n### ${f.name || "file"}\n${String(f.text).slice(0, 30000)}\n`;
  }
  if (!text.trim() && binaries.length) text = "Analyze the attached file(s) and explain the important points.";
  if (text.trim()) parts.push({ text: text.slice(0, 90000) });

  for (const f of binaries.slice(0, 2)) {
    if (!f.data || f.data.length > 3_000_000) continue;
    parts.push({ inline_data: { mime_type: f.mimeType, data: f.data } });
  }
  return parts.length ? parts : [{ text: "Hello" }];
}

function extractText(data) {
  const out = [];
  for (const c of data?.candidates || []) {
    for (const p of c?.content?.parts || []) {
      if (typeof p.text === "string" && p.text.trim()) out.push(p.text);
    }
  }
  const gm = data?.candidates?.[0]?.groundingMetadata;
  if (gm?.groundingChunks?.length && out.length) {
    const sources = [];
    for (const ch of gm.groundingChunks.slice(0, 4)) {
      const t = ch?.web?.title || ch?.web?.uri;
      if (t) sources.push(t);
    }
    if (sources.length) out.push("\nSources: " + sources.join(" · "));
  }
  return out.join("\n").trim();
}

async function postGemini(model, body, timeoutMs = 25000) {
  const key = getApiKey();
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(data?.error?.message || `${res.status}`);
      err.status = res.status;
      throw err;
    }
    const text = extractText(data);
    if (!text) throw new Error("Empty model response");
    return text;
  } finally {
    clearTimeout(timer);
  }
}

async function callGemini(history, userMessage, attachments = []) {
  if (!getApiKey()) throw new Error("Missing API key");

  // Live world context for news/current questions
  let message = String(userMessage || "");
  if (needsLiveInfo(message)) {
    try {
      const news = await fetchLiveNewsContext();
      if (news.length) {
        message += `\n\n[LIVE NEWS CONTEXT — use this as current world information]\n${news.join("\n")}\n[END LIVE NEWS CONTEXT]\nAnswer the user's question using this live context when relevant.`;
      }
    } catch (_) {}
  }

  const contents = [];
  for (const m of (history || []).slice(-6)) {
    const role = m.role === "assistant" ? "model" : "user";
    const text = String(m.content || "").slice(0, 5000);
    if (!text.trim()) continue;
    contents.push({ role, parts: [{ text }] });
  }
  contents.push({ role: "user", parts: buildParts(message, attachments) });

  const baseBody = {
    system_instruction: { parts: [{ text: SYSTEM }] },
    contents,
    generationConfig: {
      temperature: 0.45,
      topP: 0.95,
      maxOutputTokens: 3072,
    },
  };

  const errors = [];

  // Try Google Search grounding once on primary model (best when quota allows)
  try {
    return await postGemini(
      MODELS[0],
      { ...baseBody, tools: [{ google_search: {} }] },
      30000
    );
  } catch (e) {
    errors.push("grounded: " + (e.message || e));
  }

  // Standard Gemini path (stable)
  for (const model of MODELS) {
    try {
      return await postGemini(model, baseBody, model.includes("lite") ? 16000 : 28000);
    } catch (e) {
      errors.push(`${model}: ${e.message || e}`);
    }
  }
  throw new Error(errors[0] || "All models failed");
}

function offlineReply(errMsg) {
  return `Nova lost connection to Gemini for a moment${errMsg ? ` (${String(errMsg).slice(0, 160)})` : ""}.

Please send your message again. If the page was idle a long time, refresh once and retry.`;
}

export async function askNova(userMessage, history = [], attachments = [], options = {}) {
  try {
    if (options?.userId) {
      // fire-and-forget memory — never block/crash chat
      import("./db.js")
        .then((db) => db.recordNovaInteraction?.(options.userId, userMessage))
        .catch(() => {});
    }
    return await callGemini(history || [], userMessage, attachments || []);
  } catch (err) {
    console.error("Nova error:", err);
    return offlineReply(err?.message || String(err));
  }
}

export async function generateStudyTwinSummary(userId) {
  const { getWeakTopics, getStudyMemory, findMentorsForTopics, saveTwinSummary } = await import("./db.js");
  let weak = getWeakTopics(userId, 5);
  const mem = getStudyMemory(userId);
  const recent = (mem.questions || []).slice(0, 5);
  if (!weak.length && recent.length) {
    weak = recent.map((q, i) => ({ topic: q.topic || "general", score: 3 - Math.min(i, 2) }));
  }
  const mentors = findMentorsForTopics(weak.map((w) => w.topic));
  let summary = `## This week\n${weak.length ? weak.map((w) => `- ${w.topic}`).join("\n") : "- Ask Nova more questions to personalize."}`;
  try {
    const ai = await generateQuick(
      `Short weekly study briefing. Weak topics: ${weak.map((w) => w.topic).join(", ") || "none"}. Recent: ${recent.map((q) => q.text).join(" | ") || "none"}.`,
      { maxTokens: 1000 }
    );
    if (ai && ai.length > 40) summary = ai;
  } catch (_) {}
  saveTwinSummary(userId, summary);
  return { summary, weak, mentors };
}

export async function generateQuick(prompt, { maxTokens = 1200, temperature = 0.4 } = {}) {
  const body = {
    contents: [{ role: "user", parts: [{ text: String(prompt).slice(0, 40000) }] }],
    generationConfig: { temperature, topP: 0.9, maxOutputTokens: maxTokens },
  };
  let last = "failed";
  for (const model of MODELS) {
    try {
      return await postGemini(model, body, 16000);
    } catch (e) {
      last = e.message || String(e);
    }
  }
  throw new Error(last);
}

export async function fileToAttachment(file) {
  const name = file.name || "file";
  const mime = file.type || "application/octet-stream";
  const lower = name.toLowerCase();

  const textExt = /\.(txt|md|csv|json|js|ts|jsx|tsx|py|java|c|cpp|h|html|css|xml|yml|yaml|log|r|sql)$/i;
  if (mime.startsWith("text/") || textExt.test(lower)) {
    const text = await file.text();
    return { kind: "text", name, mimeType: mime || "text/plain", text };
  }

  // Images + PDF as binary inline data
  const okBinary =
    mime.startsWith("image/") ||
    mime === "application/pdf" ||
    /\.(png|jpe?g|gif|webp|pdf)$/i.test(lower);

  if (!okBinary) {
    // best-effort: try text
    try {
      const text = await file.text();
      if (text && text.length < 200000) {
        return { kind: "text", name, mimeType: "text/plain", text };
      }
    } catch (_) {}
    throw new Error(`Unsupported file type: ${name}. Use images, PDF, or text files.`);
  }

  const buf = await file.arrayBuffer();
  const bytes = new Uint8Array(buf);
  // cap ~4MB to keep localStorage / request reasonable
  if (bytes.length > 4.5 * 1024 * 1024) {
    throw new Error("File too large (max ~4MB).");
  }
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  const data = btoa(binary);
  let mimeType = mime;
  if (!mimeType || mimeType === "application/octet-stream") {
    if (/\.pdf$/i.test(lower)) mimeType = "application/pdf";
    else if (/\.png$/i.test(lower)) mimeType = "image/png";
    else if (/\.jpe?g$/i.test(lower)) mimeType = "image/jpeg";
    else if (/\.webp$/i.test(lower)) mimeType = "image/webp";
    else if (/\.gif$/i.test(lower)) mimeType = "image/gif";
  }
  return { kind: "binary", name, mimeType, data };
}



/**
 * CampusNova API client (talks to the real backend)
 */
const API_BASE = '';

function getToken() {
  return localStorage.getItem('cn_token') || '';
}

function setToken(token) {
  if (token) localStorage.setItem('cn_token', token);
  else localStorage.removeItem('cn_token');
}

async function api(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(API_BASE + path, {
    ...options,
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export const authAPI = {
  async login(email, password) {
    const data = await api('/api/auth/login', { method: 'POST', body: { email, password } });
    setToken(data.token);
    localStorage.setItem('cn_user', JSON.stringify(data.user));
    return data.user;
  },

  async register(payload) {
    const data = await api('/api/auth/register', { method: 'POST', body: payload });
    setToken(data.token);
    localStorage.setItem('cn_user', JSON.stringify(data.user));
    return data.user;
  },

  async me() {
    const data = await api('/api/auth/me');
    localStorage.setItem('cn_user', JSON.stringify(data.user));
    return data.user;
  },

  logout() {
    setToken(null);
    localStorage.removeItem('cn_user');
  },

  currentUser() {
    try {
      return JSON.parse(localStorage.getItem('cn_user') || 'null');
    } catch {
      return null;
    }
  }
};

export async function novaChat(message, history = []) {
  return api('/api/nova/chat', {
    method: 'POST',
    body: { message, history }
  });
}

export { api, getToken, setToken };

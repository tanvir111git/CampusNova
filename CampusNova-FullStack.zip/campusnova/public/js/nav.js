/**
 * CampusNova — Shared navigation + footer
 */
import {
  initTheme,
  toggleTheme,
  getSession,
  clearSession,
  injectAmbient,
  icons,
  avatarHtml,
} from "./app.js";
import { getNotifications } from "./db.js";

const PAGES = [
  { href: "dashboard.html", label: "Dashboard", auth: true },
  { href: "groups.html", label: "Groups", auth: true },
  { href: "forum.html", label: "Forum", auth: true },
  { href: "tasks.html", label: "Tasks", auth: true },
  { href: "events.html", label: "Events", auth: true },
  { href: "mentors.html", label: "Mentors", auth: true },
  { href: "research.html", label: "Research", auth: true },
  { href: "directory.html", label: "Directory", auth: true },
  { href: "notes.html", label: "Notes", auth: true },
  { href: "calendar.html", label: "Calendar", auth: true },
  { href: "studyvault.html", label: "StudyVault", auth: true },
  { href: "warroom.html", label: "War Rooms", auth: true },
  { href: "studytwin.html", label: "Study Twin", auth: true },
  { href: "tools.html", label: "AI Tools", auth: true },
  { href: "assistant.html", label: "Nova AI", auth: true },
  { href: "admin.html", label: "Admin", auth: true, adminOnly: true },
];

export function renderNav() {
  initTheme();
  injectAmbient();

  const user = getSession();
  const path = location.pathname.split("/").pop() || "index.html";
  const unread = user ? getNotifications(user.id).filter((n) => !n.read).length : 0;
  const isAdmin = user && user.role === "admin";
  const themeIcon = document.documentElement.getAttribute("data-theme") === "light" ? icons.moon : icons.sun;

  const links = PAGES.filter((p) => {
    if (!user) return false;
    if (p.adminOnly && !isAdmin) return false;
    return p.auth;
  })
    .map((p) => `<a href="${p.href}" class="${path === p.href ? "active" : ""}">${p.label}</a>`)
    .join("");

  const brand = `
    <a href="${user ? "dashboard.html" : "index.html"}" class="brand">
      <img src="assets/logo-icon.png" alt="CampusNova" class="brand-mark brand-logo" width="36" height="36" />
      <span>CampusNova</span>
    </a>
  `;

  let right = "";
  if (user) {
    right = `
      <div class="nav-right">
        <button type="button" class="nav-tool-btn" id="theme-btn" title="Dark / Light mode" aria-label="Toggle theme">
          ${themeIcon}
        </button>
        <a href="notifications.html" class="nav-tool-btn nav-bell" title="Notifications" aria-label="Notifications">
          ${icons.bell}
          ${unread ? `<span class="nav-badge">${unread > 9 ? "9+" : unread}</span>` : ""}
        </a>
        <a href="profile.html" class="nav-profile" title="${user.name}" aria-label="Profile">
          ${avatarHtml(user, "")}
        </a>
        <button type="button" class="nav-tool-btn nav-logout-btn" id="logout-btn" title="Log out" aria-label="Log out">
          ${icons.logout}
        </button>
        <button type="button" class="nav-toggle" id="nav-toggle" aria-label="Menu">${icons.menu}</button>
      </div>
    `;
  } else {
    right = `
      <div class="nav-right">
        <button type="button" class="nav-tool-btn" id="theme-btn" title="Dark / Light mode" aria-label="Toggle theme">
          ${themeIcon}
        </button>
        <a href="login.html" class="btn btn-ghost btn-sm">Log in</a>
        <a href="signup.html" class="btn btn-primary btn-sm">Sign up</a>
      </div>
    `;
  }

  const navEl = document.getElementById("site-nav");
  if (navEl) {
    navEl.innerHTML = `
      <div class="nav-inner">
        ${brand}
        <nav class="nav-links" id="nav-links">${links}</nav>
        ${right}
      </div>
    `;

    document.getElementById("theme-btn")?.addEventListener("click", () => {
      const next = toggleTheme();
      const btn = document.getElementById("theme-btn");
      if (btn) btn.innerHTML = next === "light" ? icons.moon : icons.sun;
    });

    document.getElementById("logout-btn")?.addEventListener("click", () => {
      clearSession();
      location.href = "index.html";
    });

    document.getElementById("nav-toggle")?.addEventListener("click", () => {
      document.getElementById("nav-links")?.classList.toggle("open");
    });
  }

  const foot = document.getElementById("site-footer");
  if (foot) {
    foot.innerHTML = `
      <div class="container footer-inner">
        <div style="display:flex;align-items:center;gap:0.6rem">
          <img src="assets/logo-icon.png" alt="" width="28" height="28" style="border-radius:6px;background:#fff" />
          <strong style="color:var(--text)">CampusNova</strong>
          <span style="color:var(--text-soft)">Student Collaboration Hub</span>
        </div>
        <div style="color:var(--text-soft);font-size:0.85rem">Built for students · Learn together</div>
      </div>
    `;
  }
}

renderNav();

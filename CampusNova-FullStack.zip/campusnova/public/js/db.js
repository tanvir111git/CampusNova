/**
 * CampusNova — Local database (localStorage)
 * Roles: student | teacher | admin
 */

const DB_KEY = "campusnova_db_v3";

const ADMIN_ACCOUNTS = [
  { email: "tanvir242-35-512@diu.edu.bd", password: "123thr111", name: "Md. Tanvir Hossain", id: "admin1" },
  { email: "sukanta242-35-493@diu.edu.bd", password: "123ss111", name: "Sukanta Sarkar", id: "admin2" },
  { email: "mehedi242-35-046@diu.edu.bd", password: "123mh111", name: "Mehedi Hasan", id: "admin3" },
  { email: "pulock242-35-599@diu.edu.bd", password: "123pr111", name: "Pulok Roy", id: "admin4" },
];

const SEED = {
  users: [
    ...ADMIN_ACCOUNTS.map((a) => ({
      id: a.id,
      name: a.name,
      email: a.email,
      password: a.password,
      role: "admin",
      department: "CSE",
      batch: "2024",
      bio: "CampusNova administrator & Team WebForge member.",
      skills: ["Leadership", "QA", "Web Development"],
      expertise: ["System Design", "Project Management"],
      avatarSeed: a.name.split(" ")[0].toLowerCase(),
      xp: 1000,
      level: 10,
      streak: 30,
      theme: "dark",
      createdAt: "2026-05-01T10:00:00Z",
    })),
    {
      id: "t1",
      name: "Dr. Sarah Ahmed",
      email: "sarah.ahmed@diu.edu.bd",
      password: "teacher123",
      role: "teacher",
      department: "Computer Science & Engineering",
      batch: "Faculty",
      bio: "Associate Professor specializing in Machine Learning and Data Science. 12+ years teaching experience. Open for mentorship on AI research and final-year projects.",
      skills: ["Machine Learning", "Python", "Research Methods", "Deep Learning"],
      expertise: ["Artificial Intelligence", "Data Science", "Neural Networks"],
      avatarSeed: "sarah",
      xp: 2500,
      level: 15,
      streak: 90,
      theme: "light",
      createdAt: "2026-04-01T10:00:00Z",
    },
    {
      id: "t2",
      name: "Prof. Karim Hassan",
      email: "karim.hassan@diu.edu.bd",
      password: "teacher123",
      role: "teacher",
      department: "Software Engineering",
      batch: "Faculty",
      bio: "Professor of Software Engineering. Research interests in distributed systems and cloud architecture. Mentors students on industry-ready projects.",
      skills: ["Software Architecture", "Cloud Computing", "Java", "System Design"],
      expertise: ["Distributed Systems", "Cloud", "DevOps"],
      avatarSeed: "karim",
      xp: 2200,
      level: 14,
      streak: 60,
      theme: "dark",
      createdAt: "2026-04-05T10:00:00Z",
    },
    {
      id: "t3",
      name: "Ms. Fatima Noor",
      email: "fatima.noor@diu.edu.bd",
      password: "teacher123",
      role: "teacher",
      department: "Computer Science & Engineering",
      batch: "Faculty",
      bio: "Lecturer in Web Technologies and Human-Computer Interaction. Passionate about helping first-year students build strong foundations.",
      skills: ["HTML/CSS", "JavaScript", "UI/UX", "React"],
      expertise: ["Web Engineering", "HCI", "Frontend"],
      avatarSeed: "fatima",
      xp: 1800,
      level: 12,
      streak: 45,
      theme: "light",
      createdAt: "2026-04-10T10:00:00Z",
    },
    {
      id: "u1",
      name: "Anika Rahman",
      email: "anika@student.edu",
      password: "demo123",
      role: "student",
      department: "Computer Science",
      batch: "2025",
      university: "Daffodil International University",
      bio: "First-year CS student looking for study partners in Calculus and Programming.",
      skills: ["Python", "Calculus", "Note-taking"],
      expertise: [],
      avatarSeed: "anika",
      xp: 120,
      level: 2,
      streak: 3,
      theme: "dark",
      createdAt: "2026-07-10T10:00:00Z",
    },
    {
      id: "u2",
      name: "Rafi Ahmed",
      email: "rafi@student.edu",
      password: "demo123",
      role: "student",
      department: "Software Engineering",
      batch: "2024",
      university: "Daffodil International University",
      bio: "Group project lead. Love building things and mentoring juniors.",
      skills: ["JavaScript", "React", "Project Management", "UI Design"],
      expertise: [],
      avatarSeed: "rafi",
      xp: 480,
      level: 5,
      streak: 12,
      theme: "dark",
      createdAt: "2026-06-01T10:00:00Z",
    },
    {
      id: "u3",
      name: "Nusrat Jahan",
      email: "nusrat@student.edu",
      password: "demo123",
      role: "student",
      department: "Computer Science",
      batch: "2023",
      university: "Daffodil International University",
      bio: "Club coordinator. Passionate about community and events.",
      skills: ["Event Planning", "Public Speaking", "Java", "Leadership"],
      expertise: [],
      avatarSeed: "nusrat",
      xp: 720,
      level: 7,
      streak: 21,
      theme: "light",
      createdAt: "2026-05-15T10:00:00Z",
    },
    {
      id: "u4",
      name: "Tanvir Hossain",
      email: "tanvir@student.edu",
      password: "demo123",
      role: "student",
      department: "CSE",
      batch: "2024",
      university: "Daffodil International University",
      bio: "Team leader & QA enthusiast.",
      skills: ["Testing", "Documentation", "HTML/CSS", "Leadership"],
      expertise: [],
      avatarSeed: "tanvir",
      xp: 350,
      level: 4,
      streak: 7,
      theme: "dark",
      createdAt: "2026-06-20T10:00:00Z",
    },
  ],
  groups: [
    {
      id: "g1",
      name: "CSE 101 Study Circle",
      course: "Introduction to Programming",
      description: "Weekly problem-solving sessions for first-year programming course. All skill levels welcome.",
      members: ["u1", "u2", "u4"],
      ownerId: "u2",
      tags: ["Programming", "Python", "Beginner"],
      createdAt: "2026-07-01T10:00:00Z",
    },
    {
      id: "g2",
      name: "Discrete Math Warriors",
      course: "Discrete Mathematics",
      description: "Proof practice, set theory, graph theory. Exam prep focused.",
      members: ["u1", "u3"],
      ownerId: "u3",
      tags: ["Math", "Proofs", "Exam Prep"],
      createdAt: "2026-07-05T10:00:00Z",
    },
    {
      id: "g3",
      name: "Web Dev Collective",
      course: "Web Engineering",
      description: "HTML, CSS, JS, and modern frameworks. Build projects together.",
      members: ["u2", "u4", "t3"],
      ownerId: "u2",
      tags: ["Web", "JavaScript", "Frontend"],
      createdAt: "2026-06-28T10:00:00Z",
    },
    {
      id: "g4",
      name: "Campus Hackers Club",
      course: "Interest Group",
      description: "Hackathons, side projects, and tech talks. Open to all departments.",
      members: ["u1", "u2", "u3", "u4"],
      ownerId: "u3",
      tags: ["Hackathon", "Projects", "Networking"],
      createdAt: "2026-06-15T10:00:00Z",
    },
  ],
  resources: [
    {
      id: "r1",
      groupId: "g1",
      title: "Python Basics Cheat Sheet",
      type: "notes",
      fileName: "python-cheatsheet.pdf",
      fileType: "application/pdf",
      fileSize: 245000,
      dataUrl: null,
      url: "#",
      uploadedBy: "u2",
      createdAt: "2026-07-12T10:00:00Z",
    },
    {
      id: "r2",
      groupId: "g1",
      title: "Past Midterm 2025",
      type: "past-paper",
      fileName: "midterm-2025.pdf",
      fileType: "application/pdf",
      fileSize: 512000,
      dataUrl: null,
      url: "#",
      uploadedBy: "u4",
      createdAt: "2026-07-14T10:00:00Z",
    },
    {
      id: "r3",
      groupId: "g2",
      title: "Graph Theory Summary",
      type: "notes",
      fileName: "graph-theory.docx",
      fileType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      fileSize: 128000,
      dataUrl: null,
      url: "#",
      uploadedBy: "u3",
      createdAt: "2026-07-10T10:00:00Z",
    },
    {
      id: "r4",
      groupId: "g3",
      title: "CSS Flexbox Guide",
      type: "link",
      fileName: null,
      fileType: null,
      fileSize: 0,
      dataUrl: null,
      url: "https://css-tricks.com/snippets/css/a-guide-to-flexbox/",
      uploadedBy: "u2",
      createdAt: "2026-07-08T10:00:00Z",
    },
  ],
  posts: [
    {
      id: "p1",
      groupId: "g1",
      authorId: "u1",
      title: "How to approach nested loops?",
      body: "I am struggling with problems that require nested for-loops. Any tips or practice resources?",
      upvotes: 5,
      upvotedBy: ["u2", "u4"],
      replies: [
        { id: "rp1", authorId: "u2", body: "Start by drawing the outer loop on paper, then ask what the inner loop should do for each outer step. Practice with pattern printing!", createdAt: "2026-07-15T11:00:00Z" },
        { id: "rp2", authorId: "u4", body: "I found the Coding Bat site really helpful for this.", createdAt: "2026-07-15T12:30:00Z" },
      ],
      createdAt: "2026-07-15T10:00:00Z",
    },
    {
      id: "p2",
      groupId: "g2",
      authorId: "u3",
      title: "Proof of handshaking lemma",
      body: "Can someone walk through a clean proof of the handshaking lemma? Exam is next week.",
      upvotes: 8,
      upvotedBy: ["u1"],
      replies: [
        { id: "rp3", authorId: "u1", body: "Count the sum of degrees two ways: each edge contributes 2. So sum deg(v) = 2|E|.", createdAt: "2026-07-16T09:00:00Z" },
      ],
      createdAt: "2026-07-16T08:00:00Z",
    },
  ],
  researchPosts: [
    {
      id: "rp_1",
      authorId: "t1",
      title: "Getting started with ML research as an undergrad",
      body: "Many students ask how to begin research in machine learning. Start by reading survey papers, reproduce a simple experiment (e.g. MNIST CNN), and join a lab. Happy to mentor motivated students.",
      tags: ["Machine Learning", "Undergraduate Research", "Getting Started"],
      upvotes: 12,
      upvotedBy: ["u2", "u3"],
      replies: [
        { id: "rr1", authorId: "u2", body: "Thank you Dr. Sarah! Any recommended survey papers for beginners?", createdAt: "2026-07-18T10:00:00Z" },
        { id: "rr2", authorId: "t1", body: "Start with Deep Learning by LeCun, Bengio, Hinton (Nature 2015) and the Goodfellow textbook chapters 1-6.", createdAt: "2026-07-18T14:00:00Z" },
      ],
      createdAt: "2026-07-17T09:00:00Z",
    },
    {
      id: "rp_2",
      authorId: "t2",
      title: "Open research problems in distributed systems",
      body: "Looking for collaborators on consistency models under network partitions. Undergrads welcome if you have OS / networking background.",
      tags: ["Distributed Systems", "Research Collaboration"],
      upvotes: 7,
      upvotedBy: ["u4"],
      replies: [],
      createdAt: "2026-07-19T11:00:00Z",
    },
  ],
  researchResources: [
    {
      id: "rrs1",
      title: "How to Read a Research Paper (checklist)",
      type: "guide",
      fileName: "reading-papers.pdf",
      fileType: "application/pdf",
      fileSize: 180000,
      dataUrl: null,
      url: "#",
      uploadedBy: "t1",
      tags: ["Research Methods"],
      createdAt: "2026-07-10T10:00:00Z",
    },
    {
      id: "rrs2",
      title: "LaTeX template for conference papers",
      type: "template",
      fileName: "ieee-template.zip",
      fileType: "application/zip",
      fileSize: 450000,
      dataUrl: null,
      url: "#",
      uploadedBy: "t2",
      tags: ["Writing", "LaTeX"],
      createdAt: "2026-07-12T10:00:00Z",
    },
  ],
  tasks: [
    { id: "t1", groupId: "g3", title: "Design landing page mockup", status: "done", assigneeId: "u2", due: "2026-07-20", createdAt: "2026-07-10T10:00:00Z" },
    { id: "t2", groupId: "g3", title: "Implement responsive nav", status: "in-progress", assigneeId: "u4", due: "2026-07-25", createdAt: "2026-07-12T10:00:00Z" },
    { id: "t3", groupId: "g3", title: "Write CSS design system", status: "todo", assigneeId: "u2", due: "2026-07-28", createdAt: "2026-07-14T10:00:00Z" },
    { id: "t4", groupId: "g3", title: "Add dark/light theme toggle", status: "todo", assigneeId: "u4", due: "2026-07-30", createdAt: "2026-07-15T10:00:00Z" },
    { id: "t5", groupId: "g1", title: "Solve Lab 4 problems", status: "in-progress", assigneeId: "u1", due: "2026-07-22", createdAt: "2026-07-16T10:00:00Z" },
    { id: "t6", groupId: "g1", title: "Prepare group presentation", status: "todo", assigneeId: "u2", due: "2026-08-01", createdAt: "2026-07-17T10:00:00Z" },
  ],
  events: [
    { id: "e1", title: "Orientation Workshop: How to Survive First Year", description: "Tips from seniors on study habits, campus resources, and making friends.", date: "2026-08-12T15:00:00Z", location: "Auditorium A", organizer: "Student Affairs", rsvps: ["u1"] },
    { id: "e2", title: "Hackathon 2026 — Build for Campus", description: "48-hour campus hackathon. Form teams, build solutions for student life problems. Prizes!", date: "2026-08-20T09:00:00Z", location: "Innovation Lab", organizer: "Campus Hackers Club", rsvps: ["u2", "u3", "u4"] },
    { id: "e3", title: "Guest Talk: Careers in AI", description: "Industry experts discuss pathways into machine learning and AI roles.", date: "2026-08-15T16:30:00Z", location: "Seminar Hall 2", organizer: "CSE Department", rsvps: ["u1", "u2"] },
    { id: "e4", title: "Study Group Fair", description: "Meet existing study groups and form new ones for the upcoming semester.", date: "2026-08-10T13:00:00Z", location: "Student Center", organizer: "CampusNova Team", rsvps: [] },
  ],
  notifications: [
    { id: "n1", userId: "u1", text: "Rafi replied to your question in CSE 101 Study Circle", read: false, createdAt: "2026-07-15T11:05:00Z" },
    { id: "n2", userId: "u1", text: "New event: Orientation Workshop on Aug 12", read: false, createdAt: "2026-07-18T09:00:00Z" },
    { id: "n3", userId: "u2", text: "You were assigned a new task: Write CSS design system", read: true, createdAt: "2026-07-14T10:30:00Z" },
    { id: "n4", userId: "u4", text: "Tanvir joined Web Dev Collective", read: false, createdAt: "2026-07-16T16:00:00Z" },
  ],
  mentorRequests: [],
  groupInvites: [],
  notes: [],
  personalNotes: [],
  calendarEvents: [],
  notebooks: [],
  warRooms: [],
  studyMemory: {},
};

function load() {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) {
      const db = JSON.parse(raw);
      for (const a of ADMIN_ACCOUNTS) {
        const existing = db.users.find((u) => u.email.toLowerCase() === a.email.toLowerCase());
        if (!existing) {
          db.users.push({
            id: a.id,
            name: a.name,
            email: a.email,
            password: a.password,
            role: "admin",
            department: "CSE",
            batch: "2024",
            bio: "CampusNova administrator & Team WebForge member.",
            skills: ["Leadership", "QA", "Web Development"],
            expertise: ["System Design", "Project Management"],
            avatarSeed: a.name.split(" ")[0].toLowerCase(),
            xp: 1000,
            level: 10,
            streak: 30,
            theme: "dark",
            createdAt: "2026-05-01T10:00:00Z",
          });
        } else {
          existing.password = a.password;
          existing.role = "admin";
        }
      }
      if (!db.researchPosts) db.researchPosts = SEED.researchPosts;
      if (!db.researchResources) db.researchResources = SEED.researchResources;
      if (!db.mentorRequests) db.mentorRequests = [];
      if (!db.personalNotes) db.personalNotes = [];
      if (!db.calendarEvents) db.calendarEvents = [];
      if (!db.notebooks) db.notebooks = [];
      if (!db.warRooms) db.warRooms = [];
      if (!db.warRooms.length) {
        // SEED_WAR_ROOM_DEMO
        const exam = new Date();
        exam.setDate(exam.getDate() + 5);
        exam.setHours(10, 0, 0, 0);
        const opens = new Date(exam.getTime() - 10 * 86400000);
        db.warRooms.push({
          id: "wr_demo1",
          title: "Midterm Sprint — Algorithms",
          course: "CSE 221",
          description: "Last-minute graphs, DP, and complexity practice.",
          examDate: exam.toISOString(),
          opensAt: opens.toISOString(),
          openDays: 10,
          createdBy: "t1",
          members: ["t1", "u1", "u2"],
          notes: [
            { id: "wn1", authorId: "u2", body: "Remember: Dijkstra needs non-negative weights.", createdAt: new Date().toISOString() }
          ],
          doubts: [
            { id: "wd1", authorId: "u1", text: "When do we use Bellman-Ford instead of Dijkstra?", answers: [], createdAt: new Date().toISOString() }
          ],
          mentorSlots: [],
          status: "active",
          createdAt: new Date().toISOString(),
        });
      }
      if (!db.studyMemory) db.studyMemory = {};
      (db.users || []).forEach((u) => {
        if (!Array.isArray(u.links)) u.links = [];
        if (!Array.isArray(u.projects)) u.projects = [];
        if (!Array.isArray(u.certificates)) u.certificates = [];
      });
      save(db);
      return db;
    }
  } catch (_) {}
  localStorage.setItem(DB_KEY, JSON.stringify(SEED));
  return JSON.parse(JSON.stringify(SEED));
}

function save(db) {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

export function getDB() { return load(); }

export function resetDB() {
  localStorage.setItem(DB_KEY, JSON.stringify(SEED));
  return JSON.parse(JSON.stringify(SEED));
}

export function findUserByEmail(email) {
  return load().users.find((u) => u.email.toLowerCase() === email.toLowerCase()) || null;
}

export function findUserById(id) {
  return load().users.find((u) => u.id === id) || null;
}

export function getAllUsers() { return load().users; }

export function publicUser(u) {
  if (!u) return null;
  return {
    id: u.id,
    name: u.name,
    role: u.role,
    department: u.department || "",
    batch: u.batch || "",
    university: u.university || "",
    bio: u.bio || "",
    skills: u.skills || [],
    expertise: u.expertise || [],
    photo: u.photo || null,
    avatarSeed: u.avatarSeed,
    links: u.links || [],
    projects: (u.projects || []).map((p) => ({
      id: p.id,
      title: p.title,
      description: p.description,
      url: p.url || "",
      files: (p.files || []).map((f) => ({ name: f.name, mimeType: f.mimeType, dataUrl: f.dataUrl })),
    })),
    certificates: u.certificates || [],
  };
}


export function createUser({ name, email, password, department = "", batch = "", role = "student", university = "" }) {
  const db = load();
  if (db.users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
    throw new Error("An account with this email already exists.");
  }
  if (role === "admin") role = "student";
  const user = {
    id: "u" + Date.now(),
    name,
    email,
    password,
    role: role === "teacher" ? "teacher" : "student",
    department,
    batch: role === "teacher" ? "Faculty" : batch,
    university: university || "",
    bio: "",
    skills: [],
    expertise: [],
    photo: null,
    links: [],
    projects: [],
    certificates: [],
    avatarSeed: name.split(" ")[0].toLowerCase() || "nova",
    xp: 0,
    level: 1,
    streak: 1,
    theme: "dark",
    createdAt: new Date().toISOString(),
  };
  db.users.push(user);
  save(db);
  return user;
}

export function updateUser(id, updates) {
  const db = load();
  const idx = db.users.findIndex((u) => u.id === id);
  if (idx === -1) throw new Error("User not found");
  if (updates.role === "admin" && db.users[idx].role !== "admin") delete updates.role;
  db.users[idx] = { ...db.users[idx], ...updates };
  save(db);
  return db.users[idx];
}

export function deleteUser(id) {
  const db = load();
  if (ADMIN_ACCOUNTS.some((a) => a.id === id)) throw new Error("Cannot delete core admin accounts.");
  db.users = db.users.filter((u) => u.id !== id);
  save(db);
}

export function authenticate(email, password) {
  const user = findUserByEmail(email);
  if (!user || user.password !== password) return null;
  return user;
}



export function getGroups() { return load().groups; }
export function getGroup(id) { return load().groups.find((g) => g.id === id) || null; }

export function createGroup({ name, course, description, tags, ownerId }) {
  const db = load();
  const group = {
    id: "g" + Date.now(),
    name, course, description,
    members: [ownerId],
    ownerId,
    tags: tags || [],
    createdAt: new Date().toISOString(),
  };
  db.groups.push(group);
  save(db);
  return group;
}

export function joinGroup(groupId, userId) {
  const db = load();
  const g = db.groups.find((x) => x.id === groupId);
  if (!g) throw new Error("Group not found");
  if (!g.members.includes(userId)) { g.members.push(userId); save(db); }
  return g;
}

export function leaveGroup(groupId, userId) {
  const db = load();
  const g = db.groups.find((x) => x.id === groupId);
  if (!g) throw new Error("Group not found");
  g.members = g.members.filter((m) => m !== userId);
  save(db);
  return g;
}

export function deleteGroup(id) {
  const db = load();
  db.groups = db.groups.filter((g) => g.id !== id);
  db.resources = db.resources.filter((r) => r.groupId !== id);
  db.tasks = db.tasks.filter((t) => t.groupId !== id);
  db.posts = db.posts.filter((p) => p.groupId !== id);
  save(db);
}

export function getResources(groupId) {
  return load().resources.filter((r) => r.groupId === groupId);
}

export function addResource({ groupId, title, type, url, uploadedBy, fileName, fileType, fileSize, dataUrl }) {
  const db = load();
  const r = {
    id: "r" + Date.now(),
    groupId,
    title,
    type: type || "file",
    fileName: fileName || null,
    fileType: fileType || null,
    fileSize: fileSize || 0,
    dataUrl: dataUrl || null,
    url: url || "#",
    uploadedBy,
    createdAt: new Date().toISOString(),
  };
  db.resources.push(r);
  save(db);
  return r;
}

export function deleteResource(id) {
  const db = load();
  db.resources = db.resources.filter((r) => r.id !== id);
  save(db);
}

export function getPosts(groupId) {
  const posts = load().posts;
  return groupId ? posts.filter((p) => p.groupId === groupId) : posts;
}

export function getPost(id) { return load().posts.find((p) => p.id === id) || null; }

export function createPost({ groupId, authorId, title, body }) {
  const db = load();
  const p = {
    id: "p" + Date.now(),
    groupId, authorId, title, body,
    upvotes: 0, upvotedBy: [], replies: [],
    createdAt: new Date().toISOString(),
  };
  db.posts.unshift(p);
  save(db);
  return p;
}

export function upvotePost(postId, userId) {
  const db = load();
  const p = db.posts.find((x) => x.id === postId);
  if (!p) return null;
  if (p.upvotedBy.includes(userId)) {
    p.upvotedBy = p.upvotedBy.filter((id) => id !== userId);
    p.upvotes = Math.max(0, p.upvotes - 1);
  } else {
    p.upvotedBy.push(userId);
    p.upvotes += 1;
  }
  save(db);
  return p;
}

export function addReply(postId, authorId, body) {
  const db = load();
  const p = db.posts.find((x) => x.id === postId);
  if (!p) throw new Error("Post not found");
  const reply = { id: "rp" + Date.now(), authorId, body, createdAt: new Date().toISOString() };
  p.replies.push(reply);
  save(db);
  return reply;
}

export function deletePost(id) {
  const db = load();
  db.posts = db.posts.filter((p) => p.id !== id);
  save(db);
}

export function getResearchPosts() {
  return load().researchPosts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export function getResearchPost(id) {
  return load().researchPosts.find((p) => p.id === id) || null;
}

export function createResearchPost({ authorId, title, body, tags }) {
  const db = load();
  const p = {
    id: "rp_" + Date.now(),
    authorId, title, body,
    tags: tags || [],
    upvotes: 0, upvotedBy: [], replies: [],
    createdAt: new Date().toISOString(),
  };
  db.researchPosts.unshift(p);
  save(db);
  return p;
}

export function upvoteResearchPost(postId, userId) {
  const db = load();
  const p = db.researchPosts.find((x) => x.id === postId);
  if (!p) return null;
  if (p.upvotedBy.includes(userId)) {
    p.upvotedBy = p.upvotedBy.filter((id) => id !== userId);
    p.upvotes = Math.max(0, p.upvotes - 1);
  } else {
    p.upvotedBy.push(userId);
    p.upvotes += 1;
  }
  save(db);
  return p;
}

export function addResearchReply(postId, authorId, body) {
  const db = load();
  const p = db.researchPosts.find((x) => x.id === postId);
  if (!p) throw new Error("Post not found");
  const reply = { id: "rr" + Date.now(), authorId, body, createdAt: new Date().toISOString() };
  p.replies.push(reply);
  save(db);
  return reply;
}

export function getResearchResources() {
  return load().researchResources.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export function addResearchResource({ title, type, url, uploadedBy, fileName, fileType, fileSize, dataUrl, tags }) {
  const db = load();
  const r = {
    id: "rrs" + Date.now(),
    title,
    type: type || "file",
    fileName: fileName || null,
    fileType: fileType || null,
    fileSize: fileSize || 0,
    dataUrl: dataUrl || null,
    url: url || "#",
    uploadedBy,
    tags: tags || [],
    createdAt: new Date().toISOString(),
  };
  db.researchResources.unshift(r);
  save(db);
  return r;
}

export function deleteResearchResource(id) {
  const db = load();
  db.researchResources = db.researchResources.filter((r) => r.id !== id);
  save(db);
}

export function getTasks(groupId) {
  const tasks = load().tasks;
  return groupId ? tasks.filter((t) => t.groupId === groupId) : tasks;
}

export function updateTaskStatus(taskId, status) {
  const db = load();
  const t = db.tasks.find((x) => x.id === taskId);
  if (!t) return null;
  t.status = status;
  save(db);
  return t;
}

export function createTask({ groupId, title, assigneeId, due }) {
  const db = load();
  const t = {
    id: "t" + Date.now(),
    groupId, title, status: "todo", assigneeId, due,
    createdAt: new Date().toISOString(),
  };
  db.tasks.push(t);
  save(db);
  return t;
}

export function getEvents() {
  return load().events.sort((a, b) => new Date(a.date) - new Date(b.date));
}

export function getEvent(id) {
  return load().events.find((e) => e.id === id) || null;
}

function ensureEventShape(e) {
  if (!Array.isArray(e.rsvps)) e.rsvps = [];
  if (!Array.isArray(e.declines)) e.declines = [];
  if (!Array.isArray(e.registrations)) e.registrations = [];
  return e;
}

export function createEvent({ title, description, date, location, organizer, createdBy }) {
  const db = load();
  const ev = {
    id: "e" + Date.now(),
    title: title || "Untitled event",
    description: description || "",
    date: date || new Date().toISOString(),
    location: location || "",
    organizer: organizer || "CampusNova",
    createdBy: createdBy || null,
    rsvps: [],
    declines: [],
    registrations: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  db.events.push(ev);
  // notify all non-admin users about new event
  db.users.filter((u) => u.role !== "admin").forEach((u) => {
    db.notifications.unshift({
      id: "n" + Date.now() + Math.random().toString(36).slice(2, 6),
      userId: u.id,
      text: `New event: ${ev.title} — open Events to register`,
      read: false,
      createdAt: new Date().toISOString(),
      type: "event_new",
      refId: ev.id,
    });
  });
  save(db);
  return ev;
}

export function updateEvent(id, updates, adminId) {
  const db = load();
  const e = db.events.find((x) => x.id === id);
  if (!e) throw new Error("Event not found");
  const admin = db.users.find((u) => u.id === adminId);
  if (!admin || admin.role !== "admin") throw new Error("Admin only");
  const allowed = ["title", "description", "date", "location", "organizer"];
  for (const k of allowed) {
    if (updates[k] !== undefined) e[k] = updates[k];
  }
  e.updatedAt = new Date().toISOString();
  save(db);
  return e;
}

export function deleteEvent(id, adminId) {
  const db = load();
  const admin = db.users.find((u) => u.id === adminId);
  if (!admin || admin.role !== "admin") throw new Error("Admin only");
  db.events = db.events.filter((e) => e.id !== id);
  save(db);
}

/** User registers: going | not_going */
export function registerForEvent(eventId, userId, status) {
  const db = load();
  const e = db.events.find((x) => x.id === eventId);
  if (!e) throw new Error("Event not found");
  ensureEventShape(e);
  if (status !== "going" && status !== "not_going") throw new Error("Invalid status");

  e.rsvps = e.rsvps.filter((id) => id !== userId);
  e.declines = e.declines.filter((id) => id !== userId);
  e.registrations = (e.registrations || []).filter((r) => r.userId !== userId);

  if (status === "going") e.rsvps.push(userId);
  else e.declines.push(userId);

  const user = db.users.find((u) => u.id === userId);
  const reg = {
    userId,
    status,
    at: new Date().toISOString(),
    profileSnapshot: user
      ? {
          name: user.name,
          email: user.email,
          role: user.role,
          department: user.department || "",
          batch: user.batch || "",
          university: user.university || "",
          bio: user.bio || "",
          skills: user.skills || [],
          links: user.links || [],
        }
      : null,
  };
  e.registrations.push(reg);

  // Notify all admins with profile details
  const label = status === "going" ? "participating" : "not participating";
  const detail = user
    ? `${user.name} (${user.email}) · ${user.role} · ${user.department || "—"} · Batch ${user.batch || "—"} · marked ${label} for "${e.title}"`
    : `User marked ${label} for "${e.title}"`;

  db.users.filter((u) => u.role === "admin").forEach((a) => {
    db.notifications.unshift({
      id: "n" + Date.now() + Math.random().toString(36).slice(2, 6),
      userId: a.id,
      text: detail,
      read: false,
      createdAt: new Date().toISOString(),
      type: "event_registration",
      refId: e.id,
      meta: reg.profileSnapshot,
    });
  });

  save(db);
  return e;
}

export function getEventRegistration(eventId, userId) {
  const e = load().events.find((x) => x.id === eventId);
  if (!e) return null;
  ensureEventShape(e);
  if (e.rsvps.includes(userId)) return "going";
  if (e.declines.includes(userId)) return "not_going";
  return null;
}

export function rsvpEvent(eventId, userId) {
  // toggle going for backward compatibility
  const cur = getEventRegistration(eventId, userId);
  return registerForEvent(eventId, userId, cur === "going" ? "not_going" : "going");
}

export function getNotifications(userId) {
  return load().notifications.filter((n) => n.userId === userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export function markNotifRead(id) {
  const db = load();
  const n = db.notifications.find((x) => x.id === id);
  if (n) { n.read = true; save(db); }
}

export function addNotification(userId, text) {
  const db = load();
  db.notifications.unshift({ id: "n" + Date.now(), userId, text, read: false, createdAt: new Date().toISOString() });
  save(db);
}

export function globalSearch(query) {
  const q = query.toLowerCase().trim();
  if (!q) return { groups: [], posts: [], events: [], users: [], research: [] };
  const db = load();
  return {
    groups: db.groups.filter((g) => g.name.toLowerCase().includes(q) || g.course.toLowerCase().includes(q) || g.tags.some((t) => t.toLowerCase().includes(q))),
    posts: db.posts.filter((p) => p.title.toLowerCase().includes(q) || p.body.toLowerCase().includes(q)),
    events: db.events.filter((e) => e.title.toLowerCase().includes(q) || e.description.toLowerCase().includes(q)),
    users: db.users.filter((u) => u.name.toLowerCase().includes(q) || (u.skills || []).some((s) => s.toLowerCase().includes(q)) || (u.department || "").toLowerCase().includes(q) || (u.expertise || []).some((s) => s.toLowerCase().includes(q))),
    research: (db.researchPosts || []).filter((p) => p.title.toLowerCase().includes(q) || p.body.toLowerCase().includes(q)),
  };
}

export function getDirectory() {
  return load().users.map((u) => ({
    id: u.id, name: u.name, role: u.role, department: u.department, batch: u.batch,
    university: u.university || "",
    bio: u.bio, skills: u.skills || [], expertise: u.expertise || [], avatarSeed: u.avatarSeed,
    photo: u.photo || null,
  }));
}

export function formatFileSize(bytes) {
  if (!bytes) return "—";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

export function fileIcon(fileType, fileName) {
  const t = (fileType || "").toLowerCase();
  const n = (fileName || "").toLowerCase();
  if (t.includes("pdf") || n.endsWith(".pdf")) return "📄";
  if (t.includes("image") || /\.(png|jpe?g|gif|webp|svg)$/.test(n)) return "🖼️";
  if (t.includes("presentation") || n.endsWith(".pptx") || n.endsWith(".ppt")) return "📊";
  if (t.includes("word") || n.endsWith(".docx") || n.endsWith(".doc")) return "📝";
  if (t.includes("sheet") || n.endsWith(".xlsx") || n.endsWith(".xls")) return "📗";
  if (t.includes("zip") || n.endsWith(".zip") || n.endsWith(".rar")) return "📦";
  if (t.includes("text") || n.endsWith(".txt") || n.endsWith(".md")) return "📃";
  return "📎";
}

export function readFileAsDataURL(file, maxBytes = 2 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    if (file.size > maxBytes) {
      reject(new Error("File too large. Maximum 2 MB for browser storage."));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}


export function getTeachers() {
  return load().users.filter((u) => u.role === "teacher");
}

/** Mentors = teachers only (admins are platform staff, not mentors) */
export function getMentors() {
  return load().users.filter((u) => u.role === "teacher");
}

// ---- Group invitations ----
export function getInvitesForUser(userId) {
  return (load().groupInvites || []).filter((i) => i.toUserId === userId && i.status === "pending");
}

export function getInvitesSentBy(userId) {
  return (load().groupInvites || []).filter((i) => i.fromUserId === userId);
}

export function sendGroupInvite({ groupId, fromUserId, toUserId, message }) {
  const db = load();
  if (!db.groupInvites) db.groupInvites = [];
  const group = db.groups.find((g) => g.id === groupId);
  if (!group) throw new Error("Group not found");
  if (group.members.includes(toUserId)) throw new Error("User is already a member");
  const exists = db.groupInvites.find(
    (i) => i.groupId === groupId && i.toUserId === toUserId && i.status === "pending"
  );
  if (exists) throw new Error("Invitation already pending");
  const inv = {
    id: "gi" + Date.now(),
    groupId,
    fromUserId,
    toUserId,
    message: message || "",
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  db.groupInvites.push(inv);
  // notify recipient
  db.notifications.unshift({
    id: "n" + Date.now(),
    userId: toUserId,
    text: `Group invite: ${group.name} — open Notifications to accept or decline`,
    read: false,
    createdAt: new Date().toISOString(),
    type: "group_invite",
    refId: inv.id,
  });
  save(db);
  return inv;
}

export function respondGroupInvite(inviteId, userId, accept) {
  const db = load();
  const inv = (db.groupInvites || []).find((i) => i.id === inviteId);
  if (!inv || inv.toUserId !== userId) throw new Error("Invite not found");
  if (inv.status !== "pending") throw new Error("Invite already handled");
  inv.status = accept ? "accepted" : "declined";
  inv.respondedAt = new Date().toISOString();
  if (accept) {
    const g = db.groups.find((x) => x.id === inv.groupId);
    if (g && !g.members.includes(userId)) g.members.push(userId);
  }
  save(db);
  return inv;
}

// ---- Mentor requests (group leader -> teacher) ----
export function getMentorRequestsFor(teacherId) {
  return (load().mentorRequests || []).filter((r) => r.toTeacherId === teacherId && r.status === "pending");
}

export function getMentorRequestsByGroup(groupId) {
  return (load().mentorRequests || []).filter((r) => r.groupId === groupId);
}

export function sendMentorRequest({ groupId, fromUserId, toTeacherId, message }) {
  const db = load();
  if (!db.mentorRequests) db.mentorRequests = [];
      if (!db.personalNotes) db.personalNotes = [];
      if (!db.calendarEvents) db.calendarEvents = [];
      if (!db.notebooks) db.notebooks = [];
      if (!db.warRooms) db.warRooms = [];
      if (!db.warRooms.length) {
        // SEED_WAR_ROOM_DEMO
        const exam = new Date();
        exam.setDate(exam.getDate() + 5);
        exam.setHours(10, 0, 0, 0);
        const opens = new Date(exam.getTime() - 10 * 86400000);
        db.warRooms.push({
          id: "wr_demo1",
          title: "Midterm Sprint — Algorithms",
          course: "CSE 221",
          description: "Last-minute graphs, DP, and complexity practice.",
          examDate: exam.toISOString(),
          opensAt: opens.toISOString(),
          openDays: 10,
          createdBy: "t1",
          members: ["t1", "u1", "u2"],
          notes: [
            { id: "wn1", authorId: "u2", body: "Remember: Dijkstra needs non-negative weights.", createdAt: new Date().toISOString() }
          ],
          doubts: [
            { id: "wd1", authorId: "u1", text: "When do we use Bellman-Ford instead of Dijkstra?", answers: [], createdAt: new Date().toISOString() }
          ],
          mentorSlots: [],
          status: "active",
          createdAt: new Date().toISOString(),
        });
      }
      if (!db.studyMemory) db.studyMemory = {};
      (db.users || []).forEach((u) => {
        if (!Array.isArray(u.links)) u.links = [];
        if (!Array.isArray(u.projects)) u.projects = [];
        if (!Array.isArray(u.certificates)) u.certificates = [];
      });
  const teacher = db.users.find((u) => u.id === toTeacherId && u.role === "teacher");
  if (!teacher) throw new Error("Teacher not found");
  const group = db.groups.find((g) => g.id === groupId);
  if (!group) throw new Error("Group not found");
  if (group.ownerId !== fromUserId && !group.members.includes(fromUserId)) {
    throw new Error("Only group members can request a mentor");
  }
  const exists = db.mentorRequests.find(
    (r) => r.groupId === groupId && r.toTeacherId === toTeacherId && r.status === "pending"
  );
  if (exists) throw new Error("Request already pending");
  const req = {
    id: "mr" + Date.now(),
    groupId,
    fromUserId,
    toTeacherId,
    message: message || "",
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  db.mentorRequests.push(req);
  db.notifications.unshift({
    id: "n" + Date.now(),
    userId: toTeacherId,
    text: `Mentor request for group "${group.name}" — open Notifications to respond`,
    read: false,
    createdAt: new Date().toISOString(),
    type: "mentor_request",
    refId: req.id,
  });
  save(db);
  return req;
}

export function respondMentorRequest(reqId, teacherId, accept) {
  const db = load();
  const req = (db.mentorRequests || []).find((r) => r.id === reqId);
  if (!req || req.toTeacherId !== teacherId) throw new Error("Request not found");
  if (req.status !== "pending") throw new Error("Already handled");
  req.status = accept ? "accepted" : "declined";
  req.respondedAt = new Date().toISOString();
  if (accept) {
    const g = db.groups.find((x) => x.id === req.groupId);
    if (g) {
      g.mentorId = teacherId;
      if (!g.members.includes(teacherId)) g.members.push(teacherId);
    }
  }
  // notify requester
  db.notifications.unshift({
    id: "n" + Date.now(),
    userId: req.fromUserId,
    text: accept
      ? "A mentor accepted your group request"
      : "A mentor declined your group request",
    read: false,
    createdAt: new Date().toISOString(),
  });
  save(db);
  return req;
}

// ---- Group notes (rich text/doc notes) ----
export function getNotes(groupId) {
  return (load().notes || []).filter((n) => n.groupId === groupId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export function addNote({ groupId, authorId, title, body, fileName, fileType, fileSize, dataUrl }) {
  const db = load();
  if (!db.notes) db.notes = [];
  const note = {
    id: "note" + Date.now(),
    groupId,
    authorId,
    title: title || "Untitled note",
    body: body || "",
    fileName: fileName || null,
    fileType: fileType || null,
    fileSize: fileSize || 0,
    dataUrl: dataUrl || null,
    createdAt: new Date().toISOString(),
  };
  db.notes.unshift(note);
  save(db);
  return note;
}

export function deleteNote(id, userId) {
  const db = load();
  const n = (db.notes || []).find((x) => x.id === id);
  if (!n) return;
  const user = db.users.find((u) => u.id === userId);
  if (n.authorId !== userId && user?.role !== "admin") throw new Error("Not allowed");
  db.notes = db.notes.filter((x) => x.id !== id);
  save(db);
}


// ---- Personal Keep-style notes ----
export function getPersonalNotes(userId) {
  return (load().personalNotes || [])
    .filter((n) => n.userId === userId)
    .sort((a, b) => (b.pinned === a.pinned ? new Date(b.updatedAt) - new Date(a.updatedAt) : (b.pinned ? 1 : -1)));
}

export function addPersonalNote({ userId, title, body, color }) {
  const db = load();
  if (!db.personalNotes) db.personalNotes = [];
  const note = {
    id: "pn" + Date.now(),
    userId,
    title: title || "",
    body: body || "",
    color: color || "default",
    pinned: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  db.personalNotes.unshift(note);
  save(db);
  return note;
}

export function updatePersonalNote(id, userId, updates) {
  const db = load();
  const n = (db.personalNotes || []).find((x) => x.id === id && x.userId === userId);
  if (!n) throw new Error("Note not found");
  Object.assign(n, updates, { updatedAt: new Date().toISOString() });
  save(db);
  return n;
}

export function deletePersonalNote(id, userId) {
  const db = load();
  db.personalNotes = (db.personalNotes || []).filter((x) => !(x.id === id && x.userId === userId));
  save(db);
}

// ---- Personal calendar ----
export function getCalendarEvents(userId) {
  return (load().calendarEvents || [])
    .filter((e) => e.userId === userId)
    .sort((a, b) => new Date(a.start) - new Date(b.start));
}

export function addCalendarEvent({ userId, title, date, startTime, endTime, description, color }) {
  const db = load();
  if (!db.calendarEvents) db.calendarEvents = [];
  const start = `${date}T${startTime || "09:00"}:00`;
  const end = `${date}T${endTime || "10:00"}:00`;
  const ev = {
    id: "ce" + Date.now(),
    userId,
    title: title || "Event",
    date,
    startTime: startTime || "09:00",
    endTime: endTime || "10:00",
    start,
    end,
    description: description || "",
    color: color || "#6366f1",
    createdAt: new Date().toISOString(),
  };
  db.calendarEvents.push(ev);
  save(db);
  return ev;
}

export function updateCalendarEvent(id, userId, updates) {
  const db = load();
  const e = (db.calendarEvents || []).find((x) => x.id === id && x.userId === userId);
  if (!e) throw new Error("Event not found");
  Object.assign(e, updates);
  if (updates.date || updates.startTime || updates.endTime) {
    const d = updates.date || e.date;
    const st = updates.startTime || e.startTime;
    const et = updates.endTime || e.endTime;
    e.date = d;
    e.startTime = st;
    e.endTime = et;
    e.start = `${d}T${st}:00`;
    e.end = `${d}T${et}:00`;
  }
  save(db);
  return e;
}

export function deleteCalendarEvent(id, userId) {
  const db = load();
  db.calendarEvents = (db.calendarEvents || []).filter((x) => !(x.id === id && x.userId === userId));
  save(db);
}

// ---- StudyVault (study notebooks with sources) ----
export function getNotebooks(userId) {
  return (load().notebooks || [])
    .filter((n) => n.userId === userId)
    .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
}

export function getNotebook(id, userId) {
  return (load().notebooks || []).find((n) => n.id === id && n.userId === userId) || null;
}

export function createNotebook({ userId, title }) {
  const db = load();
  if (!db.notebooks) db.notebooks = [];
      if (!db.warRooms) db.warRooms = [];
      if (!db.warRooms.length) {
        // SEED_WAR_ROOM_DEMO
        const exam = new Date();
        exam.setDate(exam.getDate() + 5);
        exam.setHours(10, 0, 0, 0);
        const opens = new Date(exam.getTime() - 10 * 86400000);
        db.warRooms.push({
          id: "wr_demo1",
          title: "Midterm Sprint — Algorithms",
          course: "CSE 221",
          description: "Last-minute graphs, DP, and complexity practice.",
          examDate: exam.toISOString(),
          opensAt: opens.toISOString(),
          openDays: 10,
          createdBy: "t1",
          members: ["t1", "u1", "u2"],
          notes: [
            { id: "wn1", authorId: "u2", body: "Remember: Dijkstra needs non-negative weights.", createdAt: new Date().toISOString() }
          ],
          doubts: [
            { id: "wd1", authorId: "u1", text: "When do we use Bellman-Ford instead of Dijkstra?", answers: [], createdAt: new Date().toISOString() }
          ],
          mentorSlots: [],
          status: "active",
          createdAt: new Date().toISOString(),
        });
      }
      if (!db.studyMemory) db.studyMemory = {};
  const nb = {
    id: "nb" + Date.now(),
    userId,
    title: title || "Untitled notebook",
    sources: [],
    summary: "",
    updatedAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  };
  db.notebooks.unshift(nb);
  save(db);
  return nb;
}

export function addNotebookSource(notebookId, userId, source) {
  const db = load();
  const nb = (db.notebooks || []).find((n) => n.id === notebookId && n.userId === userId);
  if (!nb) throw new Error("Notebook not found");
  nb.sources.push({
    id: "src" + Date.now(),
    name: source.name,
    mimeType: source.mimeType,
    kind: source.kind,
    text: source.text || null,
    data: source.data || null,
    addedAt: new Date().toISOString(),
  });
  nb.updatedAt = new Date().toISOString();
  save(db);
  return nb;
}

export function removeNotebookSource(notebookId, userId, sourceId) {
  const db = load();
  const nb = (db.notebooks || []).find((n) => n.id === notebookId && n.userId === userId);
  if (!nb) return;
  nb.sources = nb.sources.filter((s) => s.id !== sourceId);
  nb.updatedAt = new Date().toISOString();
  save(db);
}

export function saveNotebookSummary(notebookId, userId, summary) {
  const db = load();
  const nb = (db.notebooks || []).find((n) => n.id === notebookId && n.userId === userId);
  if (!nb) throw new Error("Notebook not found");
  nb.summary = summary;
  nb.updatedAt = new Date().toISOString();
  save(db);
  return nb;
}

export function updateNotebookTitle(id, userId, title) {
  const db = load();
  const nb = (db.notebooks || []).find((n) => n.id === id && n.userId === userId);
  if (!nb) return;
  nb.title = title || "Untitled notebook";
  nb.updatedAt = new Date().toISOString();
  save(db);
  return nb;
}

export function deleteNotebook(id, userId) {
  const db = load();
  db.notebooks = (db.notebooks || []).filter((n) => !(n.id === id && n.userId === userId));
  save(db);
}


// ============================================================
// Exam War Rooms
// ============================================================
function archiveExpiredWarRooms(db) {
  const now = Date.now();
  (db.warRooms || []).forEach((w) => {
    const examEnd = new Date(w.examDate).getTime() + 24 * 60 * 60 * 1000;
    if (w.status !== "archived" && now > examEnd) {
      w.status = "archived";
      w.archivedAt = new Date().toISOString();
    }
  });
}

export function getWarRooms({ includeArchived = false } = {}) {
  const db = load();
  if (!db.warRooms) db.warRooms = [];
      if (!db.warRooms.length) {
        // SEED_WAR_ROOM_DEMO
        const exam = new Date();
        exam.setDate(exam.getDate() + 5);
        exam.setHours(10, 0, 0, 0);
        const opens = new Date(exam.getTime() - 10 * 86400000);
        db.warRooms.push({
          id: "wr_demo1",
          title: "Midterm Sprint — Algorithms",
          course: "CSE 221",
          description: "Last-minute graphs, DP, and complexity practice.",
          examDate: exam.toISOString(),
          opensAt: opens.toISOString(),
          openDays: 10,
          createdBy: "t1",
          members: ["t1", "u1", "u2"],
          notes: [
            { id: "wn1", authorId: "u2", body: "Remember: Dijkstra needs non-negative weights.", createdAt: new Date().toISOString() }
          ],
          doubts: [
            { id: "wd1", authorId: "u1", text: "When do we use Bellman-Ford instead of Dijkstra?", answers: [], createdAt: new Date().toISOString() }
          ],
          mentorSlots: [],
          status: "active",
          createdAt: new Date().toISOString(),
        });
      }
  archiveExpiredWarRooms(db);
  save(db);
  let list = db.warRooms.slice();
  if (!includeArchived) list = list.filter((w) => w.status !== "archived");
  return list.sort((a, b) => new Date(a.examDate) - new Date(b.examDate));
}

export function getWarRoom(id) {
  const db = load();
  archiveExpiredWarRooms(db);
  save(db);
  return (db.warRooms || []).find((w) => w.id === id) || null;
}

export function createWarRoom({ title, course, examDate, description, createdBy, openDays = 10 }) {
  const db = load();
  if (!db.warRooms) db.warRooms = [];
      if (!db.warRooms.length) {
        // SEED_WAR_ROOM_DEMO
        const exam = new Date();
        exam.setDate(exam.getDate() + 5);
        exam.setHours(10, 0, 0, 0);
        const opens = new Date(exam.getTime() - 10 * 86400000);
        db.warRooms.push({
          id: "wr_demo1",
          title: "Midterm Sprint — Algorithms",
          course: "CSE 221",
          description: "Last-minute graphs, DP, and complexity practice.",
          examDate: exam.toISOString(),
          opensAt: opens.toISOString(),
          openDays: 10,
          createdBy: "t1",
          members: ["t1", "u1", "u2"],
          notes: [
            { id: "wn1", authorId: "u2", body: "Remember: Dijkstra needs non-negative weights.", createdAt: new Date().toISOString() }
          ],
          doubts: [
            { id: "wd1", authorId: "u1", text: "When do we use Bellman-Ford instead of Dijkstra?", answers: [], createdAt: new Date().toISOString() }
          ],
          mentorSlots: [],
          status: "active",
          createdAt: new Date().toISOString(),
        });
      }
  const exam = new Date(examDate);
  if (Number.isNaN(exam.getTime())) throw new Error("Invalid exam date");
  const openDaysN = Math.min(14, Math.max(7, Number(openDays) || 10));
  const opensAt = new Date(exam.getTime() - openDaysN * 24 * 60 * 60 * 1000);
  const room = {
    id: "wr" + Date.now(),
    title: title || "Exam War Room",
    course: course || "",
    description: description || "",
    examDate: exam.toISOString(),
    opensAt: opensAt.toISOString(),
    openDays: openDaysN,
    createdBy,
    members: createdBy ? [createdBy] : [],
    notes: [],
    doubts: [],
    mentorSlots: [],
    status: "active",
    createdAt: new Date().toISOString(),
  };
  db.warRooms.unshift(room);
  save(db);
  return room;
}

export function joinWarRoom(roomId, userId) {
  const db = load();
  const w = (db.warRooms || []).find((x) => x.id === roomId);
  if (!w) throw new Error("War room not found");
  if (w.status === "archived") throw new Error("This war room is archived");
  if (!w.members.includes(userId)) w.members.push(userId);
  save(db);
  return w;
}

export function addWarNote(roomId, { authorId, body }) {
  const db = load();
  const w = (db.warRooms || []).find((x) => x.id === roomId);
  if (!w || w.status === "archived") throw new Error("Room unavailable");
  if (!Array.isArray(w.notes)) w.notes = [];
  const note = {
    id: "wn" + Date.now(),
    authorId,
    body: (body || "").trim(),
    createdAt: new Date().toISOString(),
  };
  if (!note.body) throw new Error("Note cannot be empty");
  w.notes.unshift(note);
  save(db);
  return note;
}

export function addWarDoubt(roomId, { authorId, text }) {
  const db = load();
  const w = (db.warRooms || []).find((x) => x.id === roomId);
  if (!w || w.status === "archived") throw new Error("Room unavailable");
  const doubt = {
    id: "wd" + Date.now(),
    authorId,
    text: (text || "").trim(),
    answers: [],
    createdAt: new Date().toISOString(),
  };
  if (!doubt.text) throw new Error("Doubt cannot be empty");
  if (!Array.isArray(w.doubts)) w.doubts = [];
  w.doubts.unshift(doubt);
  // track as study activity for the author
  trackStudyEvent(authorId, { type: "doubt", topic: w.course || w.title, text: doubt.text });
  save(db);
  return doubt;
}

export function answerWarDoubt(roomId, doubtId, { authorId, text }) {
  const db = load();
  const w = (db.warRooms || []).find((x) => x.id === roomId);
  if (!w) throw new Error("Room not found");
  const d = (w.doubts || []).find((x) => x.id === doubtId);
  if (!d) throw new Error("Doubt not found");
  d.answers.push({
    id: "wa" + Date.now(),
    authorId,
    text: (text || "").trim(),
    createdAt: new Date().toISOString(),
  });
  save(db);
  return d;
}

export function addMentorSlot(roomId, { mentorId, when, note }) {
  const db = load();
  const w = (db.warRooms || []).find((x) => x.id === roomId);
  if (!w || w.status === "archived") throw new Error("Room unavailable");
  const mentor = db.users.find((u) => u.id === mentorId);
  if (!mentor || (mentor.role !== "teacher" && mentor.role !== "admin")) {
    throw new Error("Only teachers/mentors can open a drop-in slot");
  }
  const slot = {
    id: "ms" + Date.now(),
    mentorId,
    when: when || new Date().toISOString(),
    note: note || "Mentor drop-in",
    createdAt: new Date().toISOString(),
  };
  if (!Array.isArray(w.mentorSlots)) w.mentorSlots = [];
  w.mentorSlots.unshift(slot);
  save(db);
  return slot;
}

export function isWarRoomOpen(room) {
  if (!room || room.status === "archived") return false;
  const now = Date.now();
  const opens = new Date(room.opensAt).getTime();
  const closes = new Date(room.examDate).getTime() + 24 * 60 * 60 * 1000;
  return now >= opens && now <= closes;
}

// ============================================================
// Nova Memory + Personal Study Twin
// ============================================================
function ensureMemory(db, userId) {
  if (!db.studyMemory) db.studyMemory = {};
  if (!db.studyMemory[userId]) {
    db.studyMemory[userId] = {
      weakTopics: {},       // topic -> score
      questions: [],        // recent questions
      activities: [],       // generic activity log
      lastTwinSummary: null,
      lastTwinAt: null,
    };
  }
  return db.studyMemory[userId];
}

export function getStudyMemory(userId) {
  const db = load();
  const mem = ensureMemory(db, userId);
  save(db);
  return mem;
}

export function trackStudyEvent(userId, { type, topic, text }) {
  if (!userId) return;
  const db = load();
  const mem = ensureMemory(db, userId);
  const topicKey = (topic || "general").toString().slice(0, 80);
  if (!mem.weakTopics[topicKey]) mem.weakTopics[topicKey] = 0;
  if (type === "struggle" || type === "doubt" || type === "wrong") {
    mem.weakTopics[topicKey] += 2;
  } else if (type === "question") {
    mem.weakTopics[topicKey] += 1;
  } else if (type === "mastered") {
    mem.weakTopics[topicKey] = Math.max(0, mem.weakTopics[topicKey] - 2);
  }
  mem.activities.unshift({
    type: type || "activity",
    topic: topicKey,
    text: (text || "").slice(0, 300),
    at: new Date().toISOString(),
  });
  mem.activities = mem.activities.slice(0, 80);
  if (type === "question" && text) {
    mem.questions.unshift({ text: text.slice(0, 400), topic: topicKey, at: new Date().toISOString() });
    mem.questions = mem.questions.slice(0, 40);
  }
  save(db);
  return mem;
}

export function recordNovaInteraction(userId, userMessage) {
  if (!userId || !userMessage) return;
  // heuristic topic extraction from keywords
  const msg = userMessage.toLowerCase();
  const topics = [];
  const dict = [
    ["graph", "graphs"], ["tree", "trees"], ["sort", "sorting"], ["array", "arrays"],
    ["pointer", "pointers"], ["recursion", "recursion"], ["dbms", "database"],
    ["sql", "SQL"], ["network", "networking"], ["os ", "operating systems"],
    ["operating system", "operating systems"], ["calculus", "calculus"],
    ["matrix", "matrices"], ["probability", "probability"], ["react", "React"],
    ["javascript", "JavaScript"], ["python", "Python"], ["machine learning", "machine learning"],
    ["neural", "neural networks"], ["algorithm", "algorithms"], ["complexity", "complexity"],
  ];
  for (const [needle, label] of dict) {
    if (msg.includes(needle)) topics.push(label);
  }
  const topic = topics[0] || "general study";
  const struggle = /confused|don't understand|dont understand|stuck|help|weak|struggle|difficult|hard|doubt/.test(msg);
  trackStudyEvent(userId, {
    type: struggle ? "struggle" : "question",
    topic,
    text: userMessage,
  });
}

export function getWeakTopics(userId, limit = 5) {
  const mem = getStudyMemory(userId);
  return Object.entries(mem.weakTopics || {})
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([topic, score]) => ({ topic, score }));
}

export function saveTwinSummary(userId, summary) {
  const db = load();
  const mem = ensureMemory(db, userId);
  mem.lastTwinSummary = summary;
  mem.lastTwinAt = new Date().toISOString();
  save(db);
  return mem;
}

export function findMentorsForTopics(topics = []) {
  const db = load();
  const teachers = db.users.filter((u) => u.role === "teacher");
  const scored = teachers.map((t) => {
    const hay = [...(t.expertise || []), ...(t.skills || []), t.department || "", t.bio || ""]
      .join(" ")
      .toLowerCase();
    let score = 0;
    for (const topic of topics) {
      if (hay.includes(String(topic).toLowerCase().slice(0, 12))) score += 2;
    }
    return { teacher: t, score };
  });
  return scored
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((x) => x.teacher);
}


// ---- Admin power controls ----
export function adminSetUserRole(adminId, userId, newRole) {
  const db = load();
  const admin = db.users.find((u) => u.id === adminId);
  if (!admin || admin.role !== "admin") throw new Error("Admin only");
  const u = db.users.find((x) => x.id === userId);
  if (!u) throw new Error("User not found");
  if (ADMIN_ACCOUNTS.some((a) => a.id === userId) && newRole !== "admin") {
    throw new Error("Cannot demote core admin accounts");
  }
  if (!["student", "teacher", "admin"].includes(newRole)) throw new Error("Invalid role");
  u.role = newRole;
  if (newRole === "teacher" && (!u.batch || u.batch === "")) u.batch = "Faculty";
  save(db);
  return u;
}

export function adminDeletePost(adminId, postId) {
  const db = load();
  const admin = db.users.find((u) => u.id === adminId);
  if (!admin || admin.role !== "admin") throw new Error("Admin only");
  db.posts = (db.posts || []).filter((p) => p.id !== postId);
  save(db);
}

export function adminDeleteResearch(adminId, postId) {
  const db = load();
  const admin = db.users.find((u) => u.id === adminId);
  if (!admin || admin.role !== "admin") throw new Error("Admin only");
  db.researchPosts = (db.researchPosts || []).filter((p) => p.id !== postId);
  save(db);
}

export function adminDeleteWarRoom(adminId, roomId) {
  const db = load();
  const admin = db.users.find((u) => u.id === adminId);
  if (!admin || admin.role !== "admin") throw new Error("Admin only");
  db.warRooms = (db.warRooms || []).filter((w) => w.id !== roomId);
  save(db);
}

export function getAdminStats() {
  const db = load();
  return {
    users: (db.users || []).length,
    students: (db.users || []).filter((u) => u.role === "student").length,
    teachers: (db.users || []).filter((u) => u.role === "teacher").length,
    admins: (db.users || []).filter((u) => u.role === "admin").length,
    groups: (db.groups || []).length,
    posts: (db.posts || []).length,
    events: (db.events || []).length,
    research: (db.researchPosts || []).length,
    warRooms: (db.warRooms || []).length,
    notifications: (db.notifications || []).length,
    resources: (db.resources || []).length,
  };
}

export function adminBroadcast(adminId, text) {
  const db = load();
  const admin = db.users.find((u) => u.id === adminId);
  if (!admin || admin.role !== "admin") throw new Error("Admin only");
  const msg = (text || "").trim();
  if (!msg) throw new Error("Message required");
  db.users.forEach((u) => {
    if (u.id === adminId) return;
    db.notifications.unshift({
      id: "n" + Date.now() + Math.random().toString(36).slice(2, 6),
      userId: u.id,
      text: `Admin broadcast: ${msg}`,
      read: false,
      createdAt: new Date().toISOString(),
      type: "broadcast",
    });
  });
  save(db);
}
